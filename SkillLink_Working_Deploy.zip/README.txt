SKILLLINK WORKING DEPLOYMENT

1. In Supabase SQL Editor run:
   skilllink_production.sql

2. In SkillLink.html replace:
   PAste_YOUR_PUBLISHABLE_KEY_HERE
   with your Supabase PUBLISHABLE KEY only.

   Never paste the sb_secret or service_role key.

3. Upload SkillLink.html as index.html to the GitHub repository connected to Vercel.
   If using the existing Vite project, put the working code into the site's index.html
   only if your deployment is configured for static HTML.

4. In Supabase Authentication, configure your production Site URL to your Vercel URL.
   If email confirmation is enabled, users must confirm their email before login.

5. Create the first four accounts normally using Sign Up:
   - CEO 1
   - CEO 2
   - Admin
   - Partner

6. After the accounts exist, run this SQL for the actual role assignment.
   Replace the email addresses with the accounts you created:

   update public.profiles p
   set role='ceo'
   from auth.users u
   where p.id=u.id and u.email='CEO1_EMAIL';

   update public.profiles p
   set role='ceo'
   from auth.users u
   where p.id=u.id and u.email='CEO2_EMAIL';

   update public.profiles p
   set role='admin'
   from auth.users u
   where p.id=u.id and u.email='ADMIN_EMAIL';

   The normal partner signup keeps role='partner'.

This version uses Supabase Auth + PostgreSQL + RLS. It is not a fake local login.
