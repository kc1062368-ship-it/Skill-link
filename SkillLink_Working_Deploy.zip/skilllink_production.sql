
-- SKILLINK PRODUCTION DATABASE
-- Run this entire file once in Supabase SQL Editor.
-- Does NOT use or expose service_role keys.

create extension if not exists pgcrypto;

-- ---------- PROFILE / ROLE ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  username text unique,
  role text not null default 'partner'
    check (role in ('ceo','admin','partner','client')),
  referral_code text unique,
  referred_by uuid references public.profiles(id) on delete set null,
  phone text,
  avatar_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.profiles add column if not exists full_name text;
alter table public.profiles add column if not exists username text;
alter table public.profiles add column if not exists role text default 'partner';
alter table public.profiles add column if not exists referral_code text;
alter table public.profiles add column if not exists referred_by uuid;
alter table public.profiles add column if not exists phone text;
alter table public.profiles add column if not exists avatar_url text;
alter table public.profiles add column if not exists active boolean default true;
alter table public.profiles add column if not exists created_at timestamptz default now();

create unique index if not exists profiles_referral_code_idx
on public.profiles(referral_code) where referral_code is not null;

-- Generates a unique SkillLink referral code.
create or replace function public.make_referral_code()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  c text;
begin
  loop
    c := 'SL' || upper(substr(encode(gen_random_bytes(5),'hex'),1,8));
    exit when not exists(select 1 from public.profiles where referral_code=c);
  end loop;
  return c;
end;
$$;

-- New auth user -> profile.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (
    id, full_name, username, referral_code
  )
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    nullif(new.raw_user_meta_data->>'username',''),
    public.make_referral_code()
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- Backfill referral codes for existing profiles.
update public.profiles
set referral_code = public.make_referral_code()
where referral_code is null;

-- ---------- COURSES ----------
create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  category text,
  price numeric(10,2) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- PACKAGES ----------
create table if not exists public.packages (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  subtitle text,
  price numeric(10,2) not null default 0,
  partner_commission numeric(10,2) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- ENROLLMENTS ----------
create table if not exists public.enrollments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  status text not null default 'active'
    check(status in ('active','completed','paused')),
  progress integer not null default 0 check(progress between 0 and 100),
  enrolled_at timestamptz not null default now(),
  completed_at timestamptz
);

create unique index if not exists enrollments_unique
on public.enrollments(user_id, course_id);

-- ---------- PROJECTS ----------
create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  category text,
  reward numeric(10,2) not null default 0,
  status text not null default 'open'
    check(status in ('open','assigned','submitted','approved','closed')),
  client_id uuid references public.profiles(id) on delete set null,
  assigned_to uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

-- ---------- PROJECT SUBMISSIONS ----------
create table if not exists public.project_submissions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  partner_id uuid not null references public.profiles(id) on delete cascade,
  submission_url text,
  notes text,
  status text not null default 'submitted'
    check(status in ('submitted','approved','rejected')),
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz
);

-- ---------- REFERRALS ----------
create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.profiles(id) on delete cascade,
  referred_user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'registered'
    check(status in ('registered','valid','inactive')),
  created_at timestamptz not null default now(),
  unique(referrer_id, referred_user_id)
);

-- ---------- EARNINGS LEDGER ----------
create table if not exists public.earnings_ledger (
  id uuid primary key default gen_random_uuid(),
  partner_id uuid not null references public.profiles(id) on delete cascade,
  project_id uuid references public.projects(id) on delete set null,
  description text not null,
  gross_amount numeric(10,2) not null default 0,
  company_share numeric(10,2) not null default 0,
  partner_share numeric(10,2) not null default 0,
  status text not null default 'pending'
    check(status in ('pending','available','withdrawn','reversed')),
  created_at timestamptz not null default now()
);

-- ---------- WITHDRAWALS ----------
create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  partner_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(10,2) not null check(amount >= 100),
  upi_id text,
  status text not null default 'pending'
    check(status in ('pending','approved','rejected','paid')),
  approved_by uuid references public.profiles(id) on delete set null,
  note text,
  created_at timestamptz not null default now(),
  processed_at timestamptz
);

-- ---------- LEVELS ----------
create table if not exists public.levels (
  id integer primary key,
  name text unique not null,
  points integer not null,
  referrals integer not null default 0,
  reward text
);

insert into public.levels(id,name,points,referrals,reward) values
(1,'L1',100,0,'Starter'),
(2,'L2',250,15,'ID Card'),
(3,'L3',400,25,'T-Shirt'),
(4,'L4',500,40,'Certificate'),
(5,'L5',650,60,'Gift'),
(6,'L6',800,80,'Advanced Gift'),
(7,'L7',1000,100,'Gadget'),
(8,'L8',1500,150,'Special Reward'),
(9,'L9',2000,200,'Premium Reward')
on conflict(id) do update set
name=excluded.name, points=excluded.points,
referrals=excluded.referrals, reward=excluded.reward;

-- ---------- USER PROGRESS ----------
create table if not exists public.user_progress (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  points integer not null default 0,
  current_level integer not null default 1 references public.levels(id),
  skill_mastery boolean not null default false,
  updated_at timestamptz not null default now()
);

-- ---------- NOTIFICATIONS ----------
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  message text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- PACKAGE SEED ----------
insert into public.packages(name,subtitle,price,partner_commission) values
('Aarambh','Digital Foundation',499,100),
('Udaan','Creative + Content Skills',999,200),
('Pragati','Marketing + Client Skills',1999,400),
('Brahmastra','Advanced Digital Skills',3999,800),
('Shikhar','Leadership + Business',6999,1400)
on conflict(name) do update set
subtitle=excluded.subtitle,
price=excluded.price,
partner_commission=excluded.partner_commission;

-- ---------- COURSE SEED ----------
insert into public.courses(title,description,category,price) values
('Web Development','HTML, CSS, JavaScript, React and APIs.','Technology',499),
('Video Editing','Practical editing and content creation.','Creative',499),
('Digital Marketing','Marketing, social media and client skills.','Marketing',999),
('AI & Prompt Engineering','Practical AI tools and prompting.','AI',499),
('Freelancing','Portfolio, clients and freelance workflow.','Business',499),
('Business Essentials','Digital business foundations.','Business',999)
on conflict do nothing;

-- ---------- SECURITY / RLS ----------
alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.packages enable row level security;
alter table public.enrollments enable row level security;
alter table public.projects enable row level security;
alter table public.project_submissions enable row level security;
alter table public.referrals enable row level security;
alter table public.earnings_ledger enable row level security;
alter table public.withdrawals enable row level security;
alter table public.levels enable row level security;
alter table public.user_progress enable row level security;
alter table public.notifications enable row level security;

-- Helper functions for role checks. They read profiles with security definer
-- so role checks do not create recursive profile policies.
create or replace function public.current_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_staff()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(public.current_role() in ('ceo','admin'), false)
$$;

create or replace function public.is_ceo()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(public.current_role() = 'ceo', false)
$$;

-- Profiles
drop policy if exists "profile_self_select" on public.profiles;
drop policy if exists "profile_self_update" on public.profiles;
drop policy if exists "staff_profiles_select" on public.profiles;
drop policy if exists "staff_profiles_update" on public.profiles;

create policy "profile_self_select" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_staff());

create policy "profile_self_update" on public.profiles
for update to authenticated using (id = auth.uid())
with check (id = auth.uid());

create policy "staff_profiles_select" on public.profiles
for select to authenticated using (public.is_staff());

create policy "staff_profiles_update" on public.profiles
for update to authenticated using (public.is_ceo() or public.is_staff())
with check (public.is_ceo() or public.is_staff());

-- Public catalog
drop policy if exists "courses_public_read" on public.courses;
create policy "courses_public_read" on public.courses
for select to anon, authenticated using (active = true or public.is_staff());

drop policy if exists "packages_public_read" on public.packages;
create policy "packages_public_read" on public.packages
for select to anon, authenticated using (active = true or public.is_staff());

drop policy if exists "staff_courses_write" on public.courses;
create policy "staff_courses_write" on public.courses
for all to authenticated using (public.is_staff())
with check (public.is_staff());

drop policy if exists "staff_packages_write" on public.packages;
create policy "staff_packages_write" on public.packages
for all to authenticated using (public.is_ceo() or public.is_staff())
with check (public.is_ceo() or public.is_staff());

-- Enrollments
drop policy if exists "enroll_self_select" on public.enrollments;
drop policy if exists "enroll_self_insert" on public.enrollments;
drop policy if exists "enroll_self_update" on public.enrollments;
drop policy if exists "staff_enroll_select" on public.enrollments;

create policy "enroll_self_select" on public.enrollments
for select to authenticated using (user_id = auth.uid() or public.is_staff());

create policy "enroll_self_insert" on public.enrollments
for insert to authenticated with check (user_id = auth.uid());

create policy "enroll_self_update" on public.enrollments
for update to authenticated using (user_id = auth.uid() or public.is_staff())
with check (user_id = auth.uid() or public.is_staff());

-- Projects
drop policy if exists "projects_read" on public.projects;
drop policy if exists "projects_partner_assign" on public.projects;
drop policy if exists "projects_staff_write" on public.projects;

create policy "projects_read" on public.projects
for select to authenticated
using (
  status = 'open'
  or assigned_to = auth.uid()
  or client_id = auth.uid()
  or created_by = auth.uid()
  or public.is_staff()
);

create policy "projects_partner_assign" on public.projects
for update to authenticated
using (assigned_to = auth.uid() or status = 'open')
with check (assigned_to = auth.uid() or public.is_staff());

create policy "projects_staff_write" on public.projects
for all to authenticated using (public.is_staff())
with check (public.is_staff());

-- Submissions
drop policy if exists "submission_self" on public.project_submissions;
drop policy if exists "submission_staff" on public.project_submissions;

create policy "submission_self" on public.project_submissions
for all to authenticated
using (partner_id = auth.uid() or public.is_staff())
with check (partner_id = auth.uid() or public.is_staff());

create policy "submission_staff" on public.project_submissions
for select to authenticated using (public.is_staff());

-- Referrals
drop policy if exists "referrals_self" on public.referrals;
drop policy if exists "referrals_staff" on public.referrals;

create policy "referrals_self" on public.referrals
for select to authenticated using (referrer_id = auth.uid() or referred_user_id = auth.uid() or public.is_staff());

create policy "referrals_staff" on public.referrals
for all to authenticated using (public.is_staff())
with check (public.is_staff());

-- Earnings
drop policy if exists "earnings_self" on public.earnings_ledger;
drop policy if exists "earnings_staff" on public.earnings_ledger;

create policy "earnings_self" on public.earnings_ledger
for select to authenticated using (partner_id = auth.uid() or public.is_staff());

create policy "earnings_staff" on public.earnings_ledger
for all to authenticated using (public.is_staff())
with check (public.is_staff());

-- Withdrawals
drop policy if exists "withdraw_self" on public.withdrawals;
drop policy if exists "withdraw_staff" on public.withdrawals;

create policy "withdraw_self" on public.withdrawals
for select to authenticated using (partner_id = auth.uid() or public.is_staff());

create policy "withdraw_insert" on public.withdrawals
for insert to authenticated with check (partner_id = auth.uid() and amount >= 100);

create policy "withdraw_staff" on public.withdrawals
for update to authenticated using (public.is_staff())
with check (public.is_staff());

-- Levels
drop policy if exists "levels_read" on public.levels;
create policy "levels_read" on public.levels
for select to anon, authenticated using (true);

-- Progress
drop policy if exists "progress_self" on public.user_progress;
drop policy if exists "progress_staff" on public.user_progress;

create policy "progress_self" on public.user_progress
for select to authenticated using (user_id = auth.uid() or public.is_staff());

create policy "progress_self_update" on public.user_progress
for update to authenticated using (user_id = auth.uid())
with check (user_id = auth.uid());

create policy "progress_staff" on public.user_progress
for all to authenticated using (public.is_staff())
with check (public.is_staff());

-- Notifications
drop policy if exists "notifications_self" on public.notifications;
drop policy if exists "notifications_staff" on public.notifications;

create policy "notifications_self" on public.notifications
for select to authenticated using (user_id = auth.uid());

create policy "notifications_staff" on public.notifications
for all to authenticated using (public.is_staff())
with check (public.is_staff());

-- Grants
grant usage on schema public to anon, authenticated;
grant select on public.courses, public.packages, public.levels to anon, authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, update on public.enrollments to authenticated;
grant select, insert, update on public.projects to authenticated;
grant select, insert, update on public.project_submissions to authenticated;
grant select, insert, update on public.referrals to authenticated;
grant select, insert, update on public.earnings_ledger to authenticated;
grant select, insert, update on public.withdrawals to authenticated;
grant select, insert, update on public.user_progress to authenticated;
grant select on public.notifications to authenticated;

-- IMPORTANT:
-- Do not grant service_role to the browser. Supabase service_role bypasses RLS
-- and must remain server-side.
